


// de6c18375a184fbfbd8fd8054bb2c95d

//Main dishes were quite good, but desserts were too sweet for me

// https://api.meaningcloud.com/sentiment-2.1?key=de6c18375a184fbfbd8fd8054bb2c95d&of=json&txt=Main%20dishes%20were%20quite%20good,%20but%20desserts%20were%20too%20sweet%20for%20me&model=general&lang=en


let json = {
    'title': 'test json response',
    'message': 'this is a message',
    'time': 'now'
}

module.exports = json
